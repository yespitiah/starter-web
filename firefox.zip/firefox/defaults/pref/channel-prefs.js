//@line 2 "/builds/slave/rel-m-beta-lnx64-bld/build/browser/app/profile/channel-prefs.js"
pref("app.update.channel", "beta");
